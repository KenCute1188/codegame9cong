<HTML>
    <HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html;charset=UTF-8">
<META HTTP-EQUIV="Refresh" CONTENT="0; URL=?game=FreeFire">
    </HEAD>
</HTML>
