<?php
$data_sitekey = "6LdeurUqAAAAANwhjUNlW-E6vbiBn0TSw85cb12A"; // thay data-sitekey Captcha ở đây
?>